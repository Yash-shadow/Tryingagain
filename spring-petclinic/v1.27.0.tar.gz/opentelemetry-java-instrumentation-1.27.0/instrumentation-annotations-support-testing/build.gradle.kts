plugins {
  id("otel.java-conventions")
}

dependencies {
  api(project(":testing-common"))
}
