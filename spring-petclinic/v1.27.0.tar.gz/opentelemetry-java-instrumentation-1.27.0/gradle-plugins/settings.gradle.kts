pluginManagement {
  plugins {
    id("com.gradle.plugin-publish") version "1.2.0"
    id("io.github.gradle-nexus.publish-plugin") version "1.3.0"
  }
}

plugins {
  id("org.gradle.toolchains.foojay-resolver-convention") version "0.5.0"
}
