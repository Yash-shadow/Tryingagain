@ParametersAreNonnullByDefault
package io.opentelemetry.instrumentation.api.instrumenter;

import javax.annotation.ParametersAreNonnullByDefault;
