@ParametersAreNonnullByDefault
package io.opentelemetry.instrumentation.api.internal;

import javax.annotation.ParametersAreNonnullByDefault;
