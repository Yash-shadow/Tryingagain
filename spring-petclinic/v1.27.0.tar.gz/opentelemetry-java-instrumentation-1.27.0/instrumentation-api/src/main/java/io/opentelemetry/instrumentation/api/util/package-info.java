@ParametersAreNonnullByDefault
package io.opentelemetry.instrumentation.api.util;

import javax.annotation.ParametersAreNonnullByDefault;
