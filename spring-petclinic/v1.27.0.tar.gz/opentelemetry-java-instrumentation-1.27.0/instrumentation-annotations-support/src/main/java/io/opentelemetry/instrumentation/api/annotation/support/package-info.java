/** Provides utility classes to provide support for instrumenting annotated methods. */
package io.opentelemetry.instrumentation.api.annotation.support;
